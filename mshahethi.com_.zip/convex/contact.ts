import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";

export const sendMessage = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    if (!args.name.trim()) {
      throw new ConvexError("الرجاء إدخال الاسم");
    }
    if (!args.email.trim() || !args.email.includes("@")) {
      throw new ConvexError("الرجاء إدخال بريد إلكتروني صحيح");
    }
    if (!args.message.trim()) {
      throw new ConvexError("الرجاء إدخال رسالتك");
    }

    await ctx.db.insert("contactMessages", {
      name: args.name,
      email: args.email,
      phone: args.phone,
      message: args.message,
      status: "new",
    });

    return { success: true };
  },
});

export const listMessages = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("contactMessages")
      .withIndex("by_status")
      .order("desc")
      .take(50);
  },
});

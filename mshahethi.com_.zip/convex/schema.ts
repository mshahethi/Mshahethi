import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  contactMessages: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    message: v.string(),
    status: v.union(v.literal("new"), v.literal("read"), v.literal("replied")),
  }).index("by_status", ["status"]),
  
  courses: defineTable({
    title: v.string(),
    description: v.string(),
    duration: v.string(),
    level: v.string(),
    price: v.number(),
    imageUrl: v.string(),
    topics: v.array(v.string()),
    isActive: v.boolean(),
  }),
  
  consultingServices: defineTable({
    title: v.string(),
    description: v.string(),
    features: v.array(v.string()),
    duration: v.string(),
    price: v.string(),
    imageUrl: v.string(),
    isActive: v.boolean(),
  }),
  
  blogPosts: defineTable({
    title: v.string(),
    excerpt: v.string(),
    content: v.string(),
    imageUrl: v.string(),
    category: v.string(),
    readTime: v.string(),
    isPublished: v.boolean(),
  }).index("by_published", ["isPublished"]),
  
  digitalProducts: defineTable({
    title: v.string(),
    description: v.string(),
    type: v.union(v.literal("ebook"), v.literal("template"), v.literal("guide"), v.literal("toolkit")),
    price: v.number(),
    imageUrl: v.string(),
    features: v.array(v.string()),
    isActive: v.boolean(),
  }),
  
  fieldPhotos: defineTable({
    title: v.string(),
    description: v.string(),
    imageUrl: v.string(),
    category: v.string(),
    date: v.string(),
  }).index("by_category", ["category"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});

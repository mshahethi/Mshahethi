import { Toaster } from "sonner";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Courses from "./components/Courses";
import Consulting from "./components/Consulting";
import Blog from "./components/Blog";
import DigitalProducts from "./components/DigitalProducts";
import FieldPhotos from "./components/FieldPhotos";
import About from "./components/About";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import Navigation from "./components/Navigation";

export default function App() {
  return (
    <div className="min-h-screen bg-white" dir="rtl">
      <Navigation />
      <Hero />
      <Services />
      <Courses />
      <Consulting />
      <Blog />
      <DigitalProducts />
      <FieldPhotos />
      <About />
      <Contact />
      <Footer />
      <Toaster position="top-center" richColors />
    </div>
  );
}

import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Clock, BarChart, CheckCircle } from "lucide-react";

// بيانات تجريبية للدورات
const sampleCourses = [
  {
    title: "أساسيات التسويق الرقمي",
    description: "دورة شاملة تغطي جميع جوانب التسويق الرقمي من الصفر إلى الاحتراف",
    duration: "8 أسابيع",
    level: "مبتدئ",
    price: 1500,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/09903d29-b18f-4c82-b36d-cbefc8c8f025",
    topics: ["SEO", "وسائل التواصل", "الإعلانات المدفوعة", "تحليل البيانات"],
  },
  {
    title: "استراتيجيات النمو المتقدمة",
    description: "تعلم كيفية بناء استراتيجيات نمو فعالة وقابلة للتطبيق",
    duration: "6 أسابيع",
    level: "متقدم",
    price: 2000,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/082bc092-28b6-4f50-8336-31ae4cce2a30",
    topics: ["Growth Hacking", "تحليل السوق", "استراتيجيات التحويل", "قياس الأداء"],
  },
  {
    title: "إدارة الحملات الإعلانية",
    description: "احترف إدارة الحملات على Google و Facebook و Instagram",
    duration: "5 أسابيع",
    level: "متوسط",
    price: 1800,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/118318d3-050d-4a35-8a5b-36e08ba1b53e",
    topics: ["Google Ads", "Facebook Ads", "تحسين الميزانية", "A/B Testing"],
  },
];

export default function Courses() {
  const courses = useQuery(api.courses.list);
  const displayCourses = courses && courses.length > 0 ? courses : sampleCourses;

  return (
    <section id="courses" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            الدورات التدريبية
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            برامج تدريبية متخصصة لتطوير مهاراتك في التسويق الرقمي
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayCourses.map((course, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={course.imageUrl}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 start-4">
                  <span className="px-3 py-1 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white text-sm font-bold rounded-full shadow-lg">
                    {course.level}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-3 text-start">
                  {course.title}
                </h3>

                <p className="text-gray-600 mb-4 text-start leading-relaxed">
                  {course.description}
                </p>

                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <BarChart className="w-4 h-4" />
                    <span>{course.level}</span>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-sm text-gray-600 mb-2 text-start">محاور الدورة:</div>
                  <div className="flex flex-wrap gap-2">
                    {course.topics.map((topic, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-lg"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="text-start">
                    <div className="text-2xl font-bold text-[#2933e2]">
                      {course.price} ر.س
                    </div>
                  </div>
                  <button className="px-6 py-2 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white font-bold rounded-lg hover:shadow-lg transition-all">
                    سجل الآن
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

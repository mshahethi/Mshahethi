import { ArrowLeft, Sparkles } from "lucide-react";

export default function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background with Personal Branding */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://polished-pony-114.convex.cloud/api/storage/b99c0fcd-6661-4fd3-b96d-fa85a263b046"
          alt="محمد الشاحذي"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#2933e2]/85 via-[#2933e2]/80 to-[#1a1f8a]/85"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20 mb-6">
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span className="text-white text-sm font-medium">خبير التسويق الرقمي</span>
          </div>
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 animate-fade-in-up animate-delay-100">
          محمد الشاحذي
        </h1>

        <p className="text-xl sm:text-2xl text-gray-200 mb-4 max-w-3xl mx-auto animate-fade-in-up animate-delay-200">
          متخصص في التسويق والنمو الرقمي
        </p>

        <p className="text-lg text-gray-300 mb-12 max-w-2xl mx-auto animate-fade-in-up animate-delay-300">
          أساعد الشركات والأفراد على تحقيق النمو المستدام من خلال استراتيجيات تسويقية مبتكرة وفعالة
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up animate-delay-400">
          <button
            onClick={scrollToContact}
            className="group px-8 py-4 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white font-bold rounded-xl shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2"
          >
            ابدأ مشروعك الآن
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          </button>
          <button
            onClick={() => {
              const element = document.getElementById("services");
              if (element) element.scrollIntoView({ behavior: "smooth" });
            }}
            className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-bold rounded-xl border-2 border-white/30 hover:bg-white/20 hover:scale-105 transition-all duration-300"
          >
            استكشف الخدمات
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 start-1/2 -translate-x-1/2 z-10 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
}

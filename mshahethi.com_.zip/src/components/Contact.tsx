import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Mail, Phone, Send } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const sendMessage = useMutation(api.contact.sendMessage);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await sendMessage({
        name: formData.name,
        email: formData.email,
        phone: formData.phone || undefined,
        message: formData.message,
      });

      toast.success("تم إرسال رسالتك بنجاح! سأتواصل معك قريباً");
      setFormData({ name: "", email: "", phone: "", message: "" });
    } catch (error) {
      const message = error instanceof Error ? error.message : "حدث خطأ أثناء إرسال الرسالة";
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            تواصل معي
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            هل لديك مشروع أو استفسار؟ دعنا نتحدث عن كيفية مساعدتك في تحقيق أهدافك
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-start">
                معلومات التواصل
              </h3>
              <p className="text-gray-700 text-start mb-8 leading-relaxed">
                يسعدني التواصل معك ومناقشة احتياجاتك التسويقية. سواء كنت تبحث عن استشارة سريعة أو شراكة طويلة الأمد، أنا هنا لمساعدتك.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#2933e2] to-[#1a1f8a] flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div className="text-start">
                  <div className="text-sm text-gray-600 mb-1">البريد الإلكتروني</div>
                  <a
                    href="mailto:info@mshahethi.com"
                    className="text-lg font-semibold text-gray-900 hover:text-[#2933e2] transition-colors"
                  >
                    info@mshahethi.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div className="text-start">
                  <div className="text-sm text-gray-600 mb-1">الهاتف</div>
                  <a
                    href="tel:+201157276973"
                    className="text-lg font-semibold text-gray-900 hover:text-[#2933e2] transition-colors"
                  >
                    +20 115 727 6973
                  </a>
                </div>
              </div>
            </div>

            {/* Social Media Images */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <img
                  src="https://polished-pony-114.convex.cloud/api/storage/6b907c9f-6849-4df4-aa47-3d8b64bb99dc"
                  alt="وسائل التواصل الاجتماعي"
                  className="w-full h-48 object-cover"
                />
              </div>
              <div className="relative rounded-xl overflow-hidden shadow-lg">
                <img
                  src="https://polished-pony-114.convex.cloud/api/storage/4358f356-3b94-4302-ab13-30299d43fc99"
                  alt="التعاون المهني"
                  className="w-full h-48 object-cover"
                />
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2 text-start">
                  الاسم الكامل *
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#2933e2] focus:ring-2 focus:ring-[#2933e2]/20 outline-none transition-all"
                  placeholder="أدخل اسمك الكامل"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2 text-start">
                  البريد الإلكتروني *
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#2933e2] focus:ring-2 focus:ring-[#2933e2]/20 outline-none transition-all"
                  placeholder="example@email.com"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2 text-start">
                  رقم الهاتف (اختياري)
                </label>
                <input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#2933e2] focus:ring-2 focus:ring-[#2933e2]/20 outline-none transition-all"
                  placeholder="+966 50 000 0000"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2 text-start">
                  رسالتك *
                </label>
                <textarea
                  id="message"
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#2933e2] focus:ring-2 focus:ring-[#2933e2]/20 outline-none transition-all resize-none"
                  placeholder="أخبرني عن مشروعك أو استفسارك..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full px-6 py-4 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    جاري الإرسال...
                  </>
                ) : (
                  <>
                    إرسال الرسالة
                    <Send className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

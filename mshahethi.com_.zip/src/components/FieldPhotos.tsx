import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Calendar, MapPin } from "lucide-react";
import { useState } from "react";

// بيانات تجريبية لصور من الميدان
const samplePhotos = [
  {
    title: "زيارة ميدانية لمقر شركة تقنية ناشئة",
    description: "زيارة استكشافية لفهم احتياجات الشركة التسويقية وتقييم الوضع الحالي",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/c266e59e-6d46-47aa-8731-e93a3c980730",
    category: "زيارات ميدانية",
    date: "20 يناير 2024",
  },
  {
    title: "لقاء مع مدير تسويق شركة تجارة إلكترونية",
    description: "جلسة استشارية لمناقشة استراتيجية النمو الرقمي وخطة التسويق السنوية",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/b5e019b7-bc71-41f0-b455-bdccbcd73e57",
    category: "لقاءات عملاء",
    date: "18 يناير 2024",
  },
  {
    title: "جولة تدريبية في مركز الأعمال - الرياض",
    description: "جولة تدريبية شاملة لفريق التسويق حول أحدث أدوات التسويق الرقمي",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/bfb6c19b-d13c-4280-84cd-d1a6939a5ac6",
    category: "جولات تدريبية",
    date: "16 يناير 2024",
  },
  {
    title: "ورشة عمل التسويق الرقمي - الرياض",
    description: "ورشة عمل مكثفة حول استراتيجيات التسويق الرقمي الحديثة",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/118318d3-050d-4a35-8a5b-36e08ba1b53e",
    category: "ورش عمل",
    date: "15 يناير 2024",
  },
  {
    title: "زيارة ميدانية لمصنع منتجات استهلاكية",
    description: "زيارة لفهم عملية الإنتاج وتطوير استراتيجية تسويق المنتجات",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/ed8cfc12-35c0-4ddd-af6c-ae3cee7e6e38",
    category: "زيارات ميدانية",
    date: "12 يناير 2024",
  },
  {
    title: "مؤتمر التسويق الإلكتروني 2024",
    description: "مشاركة كمتحدث رئيسي في مؤتمر التسويق الإلكتروني",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/11aac070-6229-4833-b55f-186791ee50bd",
    category: "مؤتمرات",
    date: "10 يناير 2024",
  },
  {
    title: "لقاء مع فريق إدارة علامة تجارية كبرى",
    description: "اجتماع استراتيجي لمناقشة حملة إطلاق منتج جديد",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/082bc092-28b6-4f50-8336-31ae4cce2a30",
    category: "لقاءات عملاء",
    date: "8 يناير 2024",
  },
  {
    title: "جولة تدريبية في معهد التسويق الرقمي",
    description: "جولة تعليمية للمتدربين حول أساسيات التسويق عبر وسائل التواصل",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/4358f356-3b94-4302-ab13-30299d43fc99",
    category: "جولات تدريبية",
    date: "5 يناير 2024",
  },
  {
    title: "دورة تدريبية - إدارة الحملات الإعلانية",
    description: "تدريب عملي على إدارة الحملات الإعلانية على منصات التواصل",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/09903d29-b18f-4c82-b36d-cbefc8c8f025",
    category: "دورات",
    date: "1 يناير 2024",
  },
  {
    title: "زيارة ميدانية لمقر شركة خدمات لوجستية",
    description: "زيارة لتقييم الاحتياجات التسويقية وتطوير هوية العلامة التجارية",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/aa05e2c0-da42-4c50-ab31-bd71e6f01a89",
    category: "زيارات ميدانية",
    date: "28 ديسمبر 2023",
  },
  {
    title: "لقاء مع مؤسس شركة ناشئة في مجال التقنية",
    description: "جلسة استشارية حول بناء استراتيجية تسويق رقمي من الصفر",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/fd58bf98-fa96-4659-87fc-6bf26ef28621",
    category: "لقاءات عملاء",
    date: "25 ديسمبر 2023",
  },
  {
    title: "جولة تدريبية في مركز الابتكار - جدة",
    description: "جولة تدريبية متقدمة حول تحليل البيانات التسويقية واتخاذ القرارات",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/01667d54-60bd-4f39-88f9-80ea2bf8da90",
    category: "جولات تدريبية",
    date: "20 ديسمبر 2023",
  },
];

export default function FieldPhotos() {
  const photos = useQuery(api.fieldPhotos.list);
  const displayPhotos = photos && photos.length > 0 ? photos : samplePhotos;
  const [selectedCategory, setSelectedCategory] = useState("الكل");

  const categories = ["الكل", ...Array.from(new Set(displayPhotos.map(p => p.category)))];
  const filteredPhotos = selectedCategory === "الكل" 
    ? displayPhotos 
    : displayPhotos.filter(p => p.category === selectedCategory);

  return (
    <section id="field-photos" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            صور من الميدان
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            لحظات من الزيارات الميدانية، اللقاءات، والجولات التدريبية التي قمت بها
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                selectedCategory === category
                  ? "bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white shadow-lg"
                  : "bg-white text-gray-700 border border-gray-200 hover:border-[#2933e2] hover:text-[#2933e2]"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPhotos.map((photo, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              <div className="relative h-72 overflow-hidden">
                <img
                  src={photo.imageUrl}
                  alt={photo.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Category Badge */}
                <div className="absolute top-4 start-4">
                  <span className="px-3 py-1 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white text-sm font-bold rounded-full shadow-lg">
                    {photo.category}
                  </span>
                </div>

                {/* Overlay Content */}
                <div className="absolute bottom-0 start-0 end-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-xl font-bold mb-2 text-start">
                    {photo.title}
                  </h3>
                  <p className="text-sm text-gray-200 mb-3 text-start">
                    {photo.description}
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{photo.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

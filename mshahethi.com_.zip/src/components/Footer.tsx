import { Linkedin, Twitter, Instagram, Mail, Facebook, Music, Youtube } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Section */}
          <div>
            <div className="mb-4">
              <img
                src="https://polished-pony-114.convex.cloud/api/storage/dd4dc191-7089-44bf-b170-ef33c8e6ee0e"
                alt="شعار محمد الشاحذي"
                className="h-16 w-auto object-contain mb-3"
              />
            </div>
            <p className="text-gray-400 text-start leading-relaxed">
              متخصص في التسويق والنمو الرقمي، أساعد الشركات على تحقيق أهدافها من خلال استراتيجيات مبتكرة وفعالة.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-start">روابط سريعة</h4>
            <ul className="space-y-2 text-start">
              <li>
                <a href="#home" className="text-gray-400 hover:text-white transition-colors">
                  الرئيسية
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-white transition-colors">
                  الخدمات
                </a>
              </li>
              <li>
                <a href="#courses" className="text-gray-400 hover:text-white transition-colors">
                  الدورات
                </a>
              </li>
              <li>
                <a href="#consulting" className="text-gray-400 hover:text-white transition-colors">
                  الاستشارات
                </a>
              </li>
            </ul>
          </div>

          {/* More Links */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-start">المزيد</h4>
            <ul className="space-y-2 text-start">
              <li>
                <a href="#blog" className="text-gray-400 hover:text-white transition-colors">
                  المدونة
                </a>
              </li>
              <li>
                <a href="#products" className="text-gray-400 hover:text-white transition-colors">
                  المنتجات الرقمية
                </a>
              </li>
              <li>
                <a href="#field-photos" className="text-gray-400 hover:text-white transition-colors">
                  من الميدان
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-400 hover:text-white transition-colors">
                  تواصل معي
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Social */}
          <div>
            <h4 className="text-lg font-bold mb-4 text-start">تواصل معي</h4>
            <div className="space-y-3 mb-6">
              <a
                href="mailto:info@mshahethi.com"
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span className="text-sm">info@mshahethi.com</span>
              </a>
            </div>

            <div className="flex flex-wrap gap-3">
              <a
                href="https://www.linkedin.com/in/mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://web.facebook.com/mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://www.instagram.com/mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://x.com/mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="X (Twitter)"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="https://www.threads.net/@mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="Threads"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12.186 3.998a8.188 8.188 0 1 0 0 16.376 8.188 8.188 0 0 0 0-16.376zm4.606 7.455c-.052-.295-.102-.59-.158-.883-.056-.293-.117-.584-.184-.873a8.657 8.657 0 0 0-.258-.85 7.144 7.144 0 0 0-.338-.82c-.06-.13-.124-.257-.19-.383-.067-.126-.138-.25-.212-.372a5.515 5.515 0 0 0-.495-.66 4.993 4.993 0 0 0-.594-.608 4.384 4.384 0 0 0-.682-.508 4.02 4.02 0 0 0-.755-.39 3.824 3.824 0 0 0-.81-.234 3.888 3.888 0 0 0-.84-.088c-.282 0-.563.03-.84.088-.277.058-.547.14-.81.234a4.02 4.02 0 0 0-.755.39 4.384 4.384 0 0 0-.682.508 4.993 4.993 0 0 0-.594.608 5.515 5.515 0 0 0-.495.66c-.074.122-.145.246-.212.372-.066.126-.13.253-.19.383a7.144 7.144 0 0 0-.338.82 8.657 8.657 0 0 0-.258.85c-.067.289-.128.58-.184.873-.056.293-.106.588-.158.883a15.59 15.59 0 0 0-.088.883c-.02.294-.03.588-.03.883 0 .295.01.59.03.883.029.294.058.588.088.883.052.295.102.59.158.883.056.293.117.584.184.873.067.289.16.574.258.85.098.276.213.548.338.82.06.13.124.257.19.383.067.126.138.25.212.372.148.234.31.456.495.66.185.204.384.394.594.608.21.214.437.41.682.508.245.098.5.18.755.39.255.21.52.39.81.234.29.058.56.14.84.088.28-.052.56-.03.84-.088.28-.058.55-.14.81-.234.26-.094.51-.21.755-.39.245-.18.48-.38.682-.508.202-.128.39-.27.594-.608.204-.338.39-.66.495-.66.105-.122.19-.246.212-.372.022-.126.06-.253.19-.383.13-.13.24-.27.338-.82.098-.55.19-.85.258-.85.068-.289.128-.58.184-.873.056-.293.106-.588.158-.883.052-.295.073-.588.088-.883.015-.295.03-.588.03-.883 0-.295-.015-.59-.03-.883a15.59 15.59 0 0 0-.088-.883z"/>
                </svg>
              </a>
              <a
                href="https://www.youtube.com/@mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href="https://soundcloud.com/mshahethi"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-gray-800 hover:bg-gradient-to-br hover:from-[#2933e2] hover:to-[#1a1f8a] flex items-center justify-center transition-all"
                title="SoundCloud"
              >
                <Music className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400">
            © {currentYear} محمد الشاحذي. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}

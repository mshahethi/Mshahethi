import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Download, CheckCircle, Star } from "lucide-react";

// بيانات تجريبية للمنتجات الرقمية
const sampleProducts = [
  {
    title: "دليل التسويق الرقمي الشامل",
    description: "كتاب إلكتروني يحتوي على 150+ صفحة من الاستراتيجيات والنصائح العملية",
    type: "ebook" as const,
    price: 299,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/9338b5fd-8897-484f-a206-982730f7b683",
    features: [
      "10 فصول شاملة",
      "أمثلة عملية",
      "قوالب جاهزة",
      "تحديثات مجانية",
    ],
  },
  {
    title: "قوالب خطط تسويقية جاهزة",
    description: "مجموعة من 20 قالب احترافي لبناء خططك التسويقية بسهولة",
    type: "template" as const,
    price: 199,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/01667d54-60bd-4f39-88f9-80ea2bf8da90",
    features: [
      "20 قالب متنوع",
      "قابل للتعديل",
      "تصميم احترافي",
      "دعم فني",
    ],
  },
  {
    title: "دليل إعلانات فيسبوك المتقدم",
    description: "دليل عملي خطوة بخطوة لإنشاء وإدارة حملات إعلانية ناجحة",
    type: "guide" as const,
    price: 249,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/6b907c9f-6849-4df4-aa47-3d8b64bb99dc",
    features: [
      "استراتيجيات متقدمة",
      "حالات دراسية",
      "نصائح حصرية",
      "فيديوهات توضيحية",
    ],
  },
  {
    title: "مجموعة أدوات المسوق الرقمي",
    description: "حزمة شاملة من الأدوات والموارد التي يحتاجها كل مسوق",
    type: "toolkit" as const,
    price: 399,
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/11aac070-6229-4833-b55f-186791ee50bd",
    features: [
      "50+ أداة وقالب",
      "قوائم مرجعية",
      "أدلة سريعة",
      "موارد إضافية",
    ],
  },
];

const typeLabels = {
  ebook: "كتاب إلكتروني",
  template: "قوالب",
  guide: "دليل",
  toolkit: "مجموعة أدوات",
};

export default function DigitalProducts() {
  const products = useQuery(api.products.list);
  const displayProducts = products && products.length > 0 ? products : sampleProducts;

  return (
    <section id="products" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            المنتجات الرقمية
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            موارد رقمية جاهزة لمساعدتك في تطوير مهاراتك وتحسين نتائجك
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {displayProducts.map((product, index) => (
            <div
              key={index}
              className="group bg-gradient-to-b from-white to-gray-50 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-200"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 start-4">
                  <span className="px-3 py-1 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white text-sm font-bold rounded-full shadow-lg">
                    {typeLabels[product.type]}
                  </span>
                </div>
                <div className="absolute top-4 end-4 flex items-center gap-1 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span className="text-sm font-bold">4.9</span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 text-start line-clamp-2">
                  {product.title}
                </h3>

                <p className="text-gray-600 mb-4 text-start text-sm leading-relaxed line-clamp-2">
                  {product.description}
                </p>

                <ul className="space-y-2 mb-6">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-start text-sm">
                      <CheckCircle className="w-4 h-4 text-[#2933e2] flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-start">
                      <div className="text-2xl font-bold text-[#2933e2]">
                        {product.price} ر.س
                      </div>
                    </div>
                  </div>
                  <button className="w-full px-4 py-3 bg-gradient-to-r from-gray-900 to-gray-800 text-white font-bold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2">
                    <Download className="w-5 h-5" />
                    اشترِ الآن
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

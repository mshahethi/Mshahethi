import { Award, Briefcase, GraduationCap } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Section */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://polished-pony-114.convex.cloud/api/storage/ca3afcd2-5812-4aea-8f79-3682c24d6b6c"
                alt="محمد الشاحذي"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2933e2]/30 to-transparent"></div>
            </div>

            {/* Floating Stats */}
            <div className="absolute -bottom-6 -start-6 bg-white rounded-xl shadow-xl p-6 border border-gray-100">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#2933e2] to-[#1a1f8a] flex items-center justify-center">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">+5</div>
                  <div className="text-sm text-gray-600">سنوات خبرة</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div>
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6 text-start">
              من أنا
            </h2>

            <p className="text-lg text-gray-700 mb-8 text-start leading-relaxed">
              أساعد الشركات والأفراد على تحقيق النمو المستدام من خلال استراتيجيات تسويقية فعالة
            </p>

            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 bg-[#2933e2]/5 rounded-xl">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#2933e2] to-[#1a1f8a] flex items-center justify-center flex-shrink-0">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <div className="text-start">
                  <h4 className="font-bold text-gray-900 mb-1">الخبرة العملية</h4>
                  <p className="text-gray-700">
                    عملت مع أكثر من 50 عميل من مختلف القطاعات، وساعدتهم على تحقيق نمو ملموس في مبيعاتهم وحضورهم الرقمي
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-gray-900 rounded-xl">
                <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-5 h-5 text-gray-900" />
                </div>
                <div className="text-start">
                  <h4 className="font-bold text-white mb-1">التعلم المستمر</h4>
                  <p className="text-gray-200">
                    أحرص على متابعة أحدث الاتجاهات والأدوات في عالم التسويق الرقمي لضمان تقديم أفضل الحلول لعملائي
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

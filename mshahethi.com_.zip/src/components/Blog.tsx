import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Calendar, Clock, ArrowLeft } from "lucide-react";

// بيانات تجريبية للمدونة
const samplePosts = [
  {
    title: "كيف تبني استراتيجية تسويق رقمي ناجحة في 2024",
    excerpt: "دليل شامل لبناء استراتيجية تسويقية فعالة تحقق أهدافك وتزيد من عائد الاستثمار",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/01667d54-60bd-4f39-88f9-80ea2bf8da90",
    category: "استراتيجيات",
    readTime: "8 دقائق",
    date: "15 يناير 2024",
  },
  {
    title: "أفضل 10 أدوات للتسويق عبر وسائل التواصل الاجتماعي",
    excerpt: "اكتشف الأدوات التي يستخدمها المحترفون لإدارة حساباتهم وزيادة التفاعل",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/6b907c9f-6849-4df4-aa47-3d8b64bb99dc",
    category: "أدوات",
    readTime: "6 دقائق",
    date: "10 يناير 2024",
  },
  {
    title: "تحليل البيانات: المفتاح لتحسين حملاتك التسويقية",
    excerpt: "تعلم كيفية استخدام البيانات لاتخاذ قرارات تسويقية أفضل وتحسين الأداء",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/11aac070-6229-4833-b55f-186791ee50bd",
    category: "تحليلات",
    readTime: "10 دقائق",
    date: "5 يناير 2024",
  },
  {
    title: "SEO في 2024: ما الذي تغير وكيف تتكيف؟",
    excerpt: "آخر التحديثات في عالم تحسين محركات البحث وكيفية تطبيقها على موقعك",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/082bc092-28b6-4f50-8336-31ae4cce2a30",
    category: "SEO",
    readTime: "7 دقائق",
    date: "1 يناير 2024",
  },
  {
    title: "كيف تكتب محتوى يجذب ويحول الزوار إلى عملاء",
    excerpt: "أسرار كتابة المحتوى التسويقي الذي يحقق نتائج ملموسة",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/4358f356-3b94-4302-ab13-30299d43fc99",
    category: "كتابة المحتوى",
    readTime: "9 دقائق",
    date: "28 ديسمبر 2023",
  },
  {
    title: "الإعلانات المدفوعة: دليل المبتدئين الشامل",
    excerpt: "كل ما تحتاج معرفته لبدء حملاتك الإعلانية الأولى بنجاح",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/118318d3-050d-4a35-8a5b-36e08ba1b53e",
    category: "إعلانات",
    readTime: "12 دقيقة",
    date: "25 ديسمبر 2023",
  },
];

export default function Blog() {
  const posts = useQuery(api.blog.list);
  const displayPosts = posts && posts.length > 0 ? posts : samplePosts;

  return (
    <section id="blog" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            المدونة
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            مقالات ونصائح حول التسويق الرقمي واستراتيجيات النمو
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayPosts.map((post, index) => (
            <article
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 start-4">
                  <span className="px-3 py-1 bg-gradient-to-r from-gray-900 to-gray-800 text-white text-sm font-bold rounded-full shadow-lg">
                    {post.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3 text-start line-clamp-2 group-hover:text-[#2933e2] transition-colors">
                  {post.title}
                </h3>

                <p className="text-gray-600 mb-4 text-start leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>

                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{post.readTime}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{"date" in post ? post.date : "15 يناير 2024"}</span>
                  </div>
                </div>

                <button className="group/btn flex items-center gap-2 text-[#2933e2] font-bold hover:gap-3 transition-all">
                  اقرأ المزيد
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all">
            عرض جميع المقالات
          </button>
        </div>
      </div>
    </section>
  );
}

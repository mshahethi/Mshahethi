import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { CheckCircle, Clock, ArrowLeft } from "lucide-react";

// بيانات تجريبية للخدمات الاستشارية
const sampleServices = [
  {
    title: "استشارة استراتيجية شاملة",
    description: "تحليل شامل لوضعك الحالي وبناء خطة تسويقية متكاملة",
    features: [
      "تحليل SWOT كامل",
      "دراسة المنافسين",
      "تحديد الجمهور المستهدف",
      "خطة تسويقية لمدة 6 أشهر",
      "جلسات متابعة شهرية",
    ],
    duration: "4 أسابيع",
    price: "ابتداءً من 5,000 ر.س",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/082bc092-28b6-4f50-8336-31ae4cce2a30",
  },
  {
    title: "تحسين الحملات الإعلانية",
    description: "مراجعة وتحسين حملاتك الإعلانية الحالية لزيادة العائد",
    features: [
      "تدقيق الحملات الحالية",
      "تحسين الاستهداف",
      "تحسين الميزانية",
      "اختبار A/B",
      "تقارير أداء مفصلة",
    ],
    duration: "2-3 أسابيع",
    price: "ابتداءً من 3,000 ر.س",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/11aac070-6229-4833-b55f-186791ee50bd",
  },
  {
    title: "استشارة سريعة",
    description: "جلسة استشارية مركزة لحل مشكلة محددة أو الإجابة على أسئلتك",
    features: [
      "جلسة مدتها ساعة واحدة",
      "تحليل سريع للمشكلة",
      "توصيات عملية",
      "خطة عمل واضحة",
      "متابعة عبر البريد",
    ],
    duration: "جلسة واحدة",
    price: "500 ر.س",
    imageUrl: "https://polished-pony-114.convex.cloud/api/storage/b5e019b7-bc71-41f0-b455-bdccbcd73e57",
  },
];

export default function Consulting() {
  const services = useQuery(api.consulting.list);
  const displayServices = services && services.length > 0 ? services : sampleServices;

  return (
    <section id="consulting" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            الخدمات الاستشارية
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            استشارات متخصصة لحل تحدياتك التسويقية وتحقيق أهدافك
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {displayServices.map((service, index) => (
            <div
              key={index}
              className="group relative bg-gradient-to-b from-white to-gray-50 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:-translate-y-2"
            >
              <div className="relative h-48 rounded-xl overflow-hidden mb-6">
                <img
                  src={service.imageUrl}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>

              <h3 className="text-2xl font-bold text-gray-900 mb-3 text-start">
                {service.title}
              </h3>

              <p className="text-gray-600 mb-6 text-start leading-relaxed">
                {service.description}
              </p>

              <div className="mb-6">
                <div className="text-sm font-bold text-gray-900 mb-3 text-start">
                  ما ستحصل عليه:
                </div>
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-start">
                      <CheckCircle className="w-5 h-5 text-[#2933e2] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center gap-2 mb-6 text-gray-600">
                <Clock className="w-5 h-5" />
                <span className="text-sm">{service.duration}</span>
              </div>

              <div className="pt-6 border-t border-gray-200">
                <div className="text-3xl font-bold text-[#2933e2] mb-4 text-start">
                  {service.price}
                </div>
                <button className="w-full px-6 py-3 bg-gradient-to-r from-[#2933e2] to-[#1a1f8a] text-white font-bold rounded-xl hover:shadow-lg transition-all group flex items-center justify-center gap-2">
                  احجز استشارة
                  <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
